# DC Monitor Pro core
